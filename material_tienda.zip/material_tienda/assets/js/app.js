  document.getElementById('cartIcon').addEventListener('click', function() {
            document.getElementById('cartOverlay').style.display = 'flex';
        });
        
        document.getElementById('closeCart').addEventListener('click', function() {
            document.getElementById('cartOverlay').style.display = 'none';
        });